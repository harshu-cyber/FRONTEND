class person{
    constructor(name,age){
        this.firstname=name;
        this.age=age;
        this.birthyear=2025-age;
    }
}