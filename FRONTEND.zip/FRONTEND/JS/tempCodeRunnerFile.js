/* let month=2``;
switch(month){
    case 1:
        console.log("jan");
        break;

        case 2:
        console.log("feb");
        break;
        
        case 3:
        console.log("march");
        break;
        
        case 4:
        console.log("april");
        break;
        
        case 5:
        console.log("may");
        break;
        
        case 6:
        console.log("june");
        break;
        
        case 7:
        console.log("july");
        break;
        
        default:
            console.log("invalid");

} */


/* let n = 5;

for (let i = 1; i <= n; i++) {
  let str = "";
  for (let j = 1; j <= i; j++) {
    str += "*";
  }
  console.log(str);
} */

  var name="alice";
  var name ="bob";
  console.log(name);